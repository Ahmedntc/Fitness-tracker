import styled from "styled-components";

export const ImagemLogo = styled.img`
    width: ${props => props.width || "200px"};
    height: ${props => props.height || "300px"};


`;



