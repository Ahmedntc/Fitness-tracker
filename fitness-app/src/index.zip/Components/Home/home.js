import React from 'react';
import './Home.css';  // Import the CSS file

const Home = () => {
    return (
        <div className="home-container">
            <h1>Bem-vindo!</h1>
            <p>Armazene seus treinos aqui com facilidade e acompanhe seu progresso!</p>
        </div>
    );
};

export default Home;
